package com.elektrobit.recyclerview;

public class EmployeeData {
    String name, id, dept;

    EmployeeData(String name,
                 String id,
                 String dept) {
        this.name = name;
        this.id = id;
        this.dept = dept;
    }
}
