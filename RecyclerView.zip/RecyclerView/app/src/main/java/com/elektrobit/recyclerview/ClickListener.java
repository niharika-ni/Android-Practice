package com.elektrobit.recyclerview;

public interface ClickListener {
    public void click(int index);
}
